# 🛠️ HECHARR Full Stack Setup Guide
### Connect Real Stripe Payments + Save Every Order to a Database
#### Written for non-technical founders — every step explained simply

---

## 🗺️ What You're Building

```
Customer buys on hechar.com
         ↓
Stripe charges their card (real money ✅)
         ↓
Your backend server (Railway) saves the order
         ↓
Supabase database stores: name, email, address, items, total
         ↓
You visit YOUR_URL/orders?secret=hecharr_admin_2025
         ↓
See a beautiful table of every order 📋
```

**Services you'll use — all FREE:**
| Service | What it does | Cost |
|---|---|---|
| Supabase | Your database (like Excel in the cloud) | Free |
| Railway | Hosts your backend server | Free tier |
| Stripe | Takes payments from customers | Free (2.9% + $0.30 per sale) |

---

## PART 1 — Set Up Supabase (Your Database)

### Step 1: Create Supabase Account
1. Go to **supabase.com**
2. Click **"Start your project"**
3. Sign up with GitHub or email
4. Click **"New Project"**
5. Name it: `hecharr`
6. Set a database password (write it down somewhere safe)
7. Choose region closest to you (e.g. `West EU` or `US East`)
8. Click **"Create new project"**
9. Wait about 2 minutes for it to set up

### Step 2: Create Your Database Tables
1. In the left sidebar, click **"SQL Editor"**
2. Click **"New Query"** (top right)
3. Open the file `supabase-setup.sql` from this folder
4. Copy ALL the text inside it
5. Paste it into the SQL Editor
6. Click the green **"Run"** button (or press Ctrl+Enter)
7. You should see: `Success. No rows returned`
8. Click **"Table Editor"** in the left sidebar
9. You should now see two tables: **users** and **orders** ✅

### Step 3: Get Your Supabase Keys
1. In the left sidebar, click **"Project Settings"** (gear icon at bottom)
2. Click **"API"**
3. You'll see:
   - **Project URL** — copy this (looks like `https://abcdef123.supabase.co`)
   - **service_role** key (scroll down, under "Project API keys") — copy this too
4. Keep these safe — you'll need them in Part 3

---

## PART 2 — Set Up Railway (Your Backend Server)

Railway hosts the `server.js` file that connects Stripe and Supabase.

### Step 1: Create Railway Account
1. Go to **railway.app**
2. Click **"Login"** → **"Login with GitHub"**
3. If you don't have GitHub, create a free account at github.com first (it takes 2 minutes)

### Step 2: Upload Your Backend Code to GitHub
You need to put your backend code on GitHub so Railway can access it.

1. Go to **github.com** and log in
2. Click the **"+"** button (top right) → **"New repository"**
3. Name it: `hecharr-backend`
4. Make it **Private**
5. Click **"Create repository"**
6. On the next screen, click **"uploading an existing file"**
7. Upload these 3 files from your `backend` folder:
   - `server.js`
   - `package.json`
   - `.env.example`
8. Click **"Commit changes"**

### Step 3: Deploy to Railway
1. Go back to **railway.app**
2. Click **"New Project"**
3. Click **"Deploy from GitHub repo"**
4. Select your `hecharr-backend` repository
5. Railway will detect it's a Node.js app and start deploying
6. Wait about 60 seconds for it to build

### Step 4: Add Environment Variables to Railway
This is where you tell Railway your secret keys (Stripe, Supabase, etc.)

1. In Railway, click on your deployed service
2. Click the **"Variables"** tab
3. Add these one by one (click "Add Variable" for each):

```
STRIPE_SECRET_KEY        →  sk_live_... (from Stripe → Developers → API Keys)
STRIPE_WEBHOOK_SECRET    →  whsec_... (from Stripe → Webhooks, set up in Part 3)
SUPABASE_URL             →  https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_KEY     →  your service_role key from Supabase
ADMIN_SECRET             →  hecharr_admin_2025 (or make up your own password)
```

4. Click **"Deploy"** after adding all variables
5. Railway will restart with your new settings

### Step 5: Get Your Railway URL
1. In Railway, click **"Settings"** tab
2. Under "Domains", click **"Generate Domain"**
3. You'll get a URL like: `hecharr-backend-production.up.railway.app`
4. **Copy this URL** — you'll need it in Part 4
5. Test it: open a browser, go to that URL
6. You should see: `{"message":"🍬 HECHARR Backend is running!","status":"ok"}` ✅

---

## PART 3 — Connect Stripe Properly

### Step 1: Get Your Stripe Keys
1. Log into **stripe.com**
2. Top right, click **"Developers"**
3. Click **"API Keys"**
4. Copy your **Secret key** (starts with `sk_live_` or `sk_test_`)
5. Add this to Railway as `STRIPE_SECRET_KEY` (you already did this above)

### Step 2: Set Up Stripe Webhook
Webhooks let Stripe notify your server when payments happen.

1. In Stripe, click **"Developers"** → **"Webhooks"**
2. Click **"Add endpoint"**
3. In "Endpoint URL", enter: `YOUR_RAILWAY_URL/webhook`
   (e.g. `https://hecharr-backend-production.up.railway.app/webhook`)
4. Click **"Select events"**
5. Find and check:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
6. Click **"Add events"** → **"Add endpoint"**
7. You'll see a **"Signing secret"** — click "Reveal" and copy it
8. Add this to Railway as `STRIPE_WEBHOOK_SECRET`

---

## PART 4 — Update Your Website (index.html)

Now tell your website where your backend is.

1. Open `index.html` in any text editor (Notepad on Windows, TextEdit on Mac)
2. Find these two lines near the top of the JavaScript section:

```javascript
const STRIPE_PUBLISHABLE_KEY = 'YOUR_PUBLISHABLE_KEY';
const BACKEND_URL = 'YOUR_BACKEND_URL';
```

3. Replace them with your actual values:

```javascript
const STRIPE_PUBLISHABLE_KEY = 'pk_live_abc123...'; // your Stripe publishable key
const BACKEND_URL = 'https://hecharr-backend-production.up.railway.app'; // your Railway URL
```

4. Save the file
5. Upload the updated `index.html` to Netlify:
   - Go to netlify.com → your site
   - Drag and drop the new `index.html` file
   - Netlify updates automatically in ~30 seconds

---

## PART 5 — Test Everything End-to-End

### Test with Stripe's fake card (test mode):
Make sure Stripe is in **Test mode** (toggle in top right of Stripe dashboard)

Use this card:
- **Number:** `4242 4242 4242 4242`
- **Expiry:** `12/27`
- **CVC:** `123`
- **Name:** anything

### What should happen:
1. Add a product to cart on hechar.com ✅
2. Go through checkout, fill in your name/address ✅
3. Enter the test card, click Pay ✅
4. Payment processes (takes 2-3 seconds) ✅
5. Order confirmation screen appears ✅
6. Go to: `YOUR_RAILWAY_URL/orders?secret=hecharr_admin_2025`
7. You should see your test order in the table ✅
8. Go to Stripe dashboard → Payments → you should see the test charge ✅

### Going Live (accepting real money):
1. In Stripe, flip the toggle from **Test** to **Live**
2. Copy your **Live** publishable key (starts with `pk_live_`)
3. Update `index.html` with the live key
4. Update Railway with the live secret key (`sk_live_`)
5. Re-upload `index.html` to Netlify
6. You're live! 🎉

---

## PART 6 — Viewing Your Orders

Every time someone buys, go to:
```
YOUR_RAILWAY_URL/orders?secret=hecharr_admin_2025
```

You'll see a table with:
- Order ID
- Date
- Customer name
- Email
- Shipping city & country
- Total paid
- Status

**Bookmark this page** — it's your order dashboard.

You can also see everything in Supabase:
1. Go to supabase.com → your project
2. Click "Table Editor" → "orders"
3. Every order is there with full details

---

## 🆘 Troubleshooting

| Problem | Likely cause | Fix |
|---|---|---|
| "Payment failed" error | Wrong Stripe key | Double-check `STRIPE_SECRET_KEY` in Railway |
| Backend URL not working | Railway still deploying | Wait 2 minutes, refresh |
| Orders not saving | Wrong Supabase keys | Check `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` |
| CORS error in console | Wrong frontend URL in server.js | Add your exact domain to the CORS list |
| "Unauthorized" on /orders | Wrong admin secret | Make sure secret matches `ADMIN_SECRET` in Railway |

---

## 📞 Getting Help

- **Railway help:** docs.railway.app
- **Supabase help:** supabase.com/docs  
- **Stripe help:** stripe.com/docs
- **Stuck?** Take a screenshot of the error and ask Claude — paste the exact error message

---

*You've got this. The whole setup takes about 1-2 hours the first time. Once it's done, it runs itself forever.* 🍬
